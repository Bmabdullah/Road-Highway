//
//  Additional.swift
//  RoadsAndHighways
//
//  Created by Fahim Rahman on 13/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

// base URL
class UrlManager: NSObject {
    
    private static let BASE_URL = "http://inflack-001-site1.ftempurl.com/api/"
    
    class func baseURL() -> String {
        return BASE_URL
    }
}

// otp
var otp = String()
