//
//  TechnicalViewControllerDesign.swift
//  RoadsAndHighways
//
//  Created by AL Mustakim on 12/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

extension TechnicalViewController{
    func setupTableView(){
        technicalTableView.delegate = self
         technicalTableView.dataSource = self
        // let nib = UINib(nibName: "ItemTableViewCell", bundle: nil)
         technicalTableView.register(UINib(nibName: "SimpleTableViewCell", bundle: nil), forCellReuseIdentifier: "simpleCell")
    }
}

extension TechnicalViewController:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tabLeData?.data?.count ?? 6
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = technicalTableView.dequeueReusableCell(withIdentifier: "simpleCell", for: indexPath) as! SimpleTableViewCell
        cell.simpleCellLabel.text = tabLeData?.data?[indexPath.row].name
        return cell
    }
    
    
}

