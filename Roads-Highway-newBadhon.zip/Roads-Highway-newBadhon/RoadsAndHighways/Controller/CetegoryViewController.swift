//
//  CetegoryViewController.swift
//  RoadsAndHighways
//
//  Created by AL Mustakim on 9/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

class CetegoryViewController: UIViewController {

    @IBOutlet weak var cetegoryCollectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()

        cetegoryCollectionView.delegate = self
        cetegoryCollectionView.dataSource = self
        let nib = UINib(nibName: "ItemCollectionViewCell", bundle: nil)
        cetegoryCollectionView.register(nib, forCellWithReuseIdentifier: "cellIdentifier")
    }


    var collectionViewFlowLayout: UICollectionViewFlowLayout!


    override func viewWillLayoutSubviews() {

        super.viewWillLayoutSubviews()
        setupCollectionViewItemSize()
      }


    private func setupCollectionViewItemSize() {
        
        if collectionViewFlowLayout == nil {
            
          let numberOfItemPerRow: CGFloat = 2
          let lineSpacing: CGFloat = 10
          let interItemSpacing: CGFloat = 10

          let width = (cetegoryCollectionView.frame.width - (numberOfItemPerRow - 1) * interItemSpacing) / numberOfItemPerRow

          let height = width

          collectionViewFlowLayout = UICollectionViewFlowLayout()

          collectionViewFlowLayout.itemSize = CGSize(width: width, height: height)
          collectionViewFlowLayout.sectionInset = UIEdgeInsets.zero
          collectionViewFlowLayout.scrollDirection = .vertical
          collectionViewFlowLayout.minimumLineSpacing = lineSpacing
          collectionViewFlowLayout.minimumInteritemSpacing = interItemSpacing


          cetegoryCollectionView.setCollectionViewLayout(collectionViewFlowLayout, animated: true)
        }
      }


}

extension CetegoryViewController: UICollectionViewDelegate,UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 8
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellIdentifier", for: indexPath)

        return cell
    }


}

