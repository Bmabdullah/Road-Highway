//
//  BridgeViewControllerDesign.swift
//  RoadsAndHighways
//
//  Created by AL Mustakim on 10/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

extension BridgeViewController{
    
    func setuptableview(){
        bridgeTableView.delegate = self
                    bridgeTableView.dataSource = self
                   // let nib = UINib(nibName: "ItemTableViewCell", bundle: nil)
                    bridgeTableView.register(UINib(nibName: "ItemTableViewCell", bundle: nil), forCellReuseIdentifier: "tableCellIdentifier")
    }
}
    extension BridgeViewController:UITableViewDataSource,UITableViewDelegate{
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 100
        }
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return tabLeData?.data?.count ?? 5
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = bridgeTableView.dequeueReusableCell(withIdentifier: "tableCellIdentifier", for: indexPath) as! ItemTableViewCell
            cell.tableNibLabel.text = tabLeData?.data?[indexPath.row].displayName
            
            return cell
        }
        
        
    }


