//
//  BridgeViewController.swift
//  RoadsAndHighways
//
//  Created by AL Mustakim on 10/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

class BridgeViewController: UIViewController {
    
    var tabLeData : Employee?
    var id : Int = 0

    @IBOutlet weak var bridgeTableView: UITableView!
    override func viewDidLoad() {
            super.viewDidLoad()
           setuptableview()
        customNavigationBar()
        gettableData(token:"\(defaults.string(forKey: "token")!)")
        }
    }
extension BridgeViewController {
    
    func gettableData(token: String) {
        
        guard let loginUrl = URL(string: UrlManager.baseURL() + "rhd/GetEmployeeListByOfficeID?officeId=\(id)") else { return }
        
        var request = URLRequest(url: loginUrl)
        request.setValue("Bearer \(String(describing: token))", forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "GET"
        // request.httpBody = postData
        request.timeoutInterval = .infinity
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            
            DispatchQueue.main.async {
                
                if let response = response as? HTTPURLResponse, response.isResponseOK() {
                   // print(response)
                    
                    guard let data = data else {
                        print(String(describing: error))
                        return
                    }
                    
                    if let jsonResponse = try? JSONDecoder().decode(Employee.self, from: data) {
                        
                        
                        self.tabLeData = jsonResponse
                        
                        print(self.tabLeData)
                        
                    }
                    self.bridgeTableView.reloadData()
                    
                    hud.dismiss(animated: true)
                }
            }
        }.resume()
    }
}


