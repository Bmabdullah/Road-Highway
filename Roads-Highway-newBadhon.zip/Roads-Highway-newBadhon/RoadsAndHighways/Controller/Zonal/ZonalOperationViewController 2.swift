//
//  ZonalOperationViewController.swift
//  RoadsAndHighways
//
//  Created by AL Mustakim on 8/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

class ZonalOperationViewController: UIViewController {

    @IBOutlet weak var zonalTableView: UITableView!

   override func viewDidLoad() {
            super.viewDidLoad()
            
            customNavigationBar()
            zonalTableView.delegate = self
             zonalTableView.dataSource = self
            // let nib = UINib(nibName: "ItemTableViewCell", bundle: nil)
             zonalTableView.register(UINib(nibName: "ItemTableViewCell", bundle: nil), forCellReuseIdentifier: "tableCellIdentifier")
        }
        

      

    }
    extension ZonalOperationViewController:UITableViewDataSource,UITableViewDelegate{
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 100
        }
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return 6
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = zonalTableView.dequeueReusableCell(withIdentifier: "tableCellIdentifier", for: indexPath)
            
            return cell
        }
        
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
             DispatchQueue.main.async {
                           
                           if let nav = self.navigationController{
                               Navigation.shared.nextViewControllerwithID(stroyBoardID: "Badhon",storyBoardName: "SubZoneCircleViewController", navigationController: nav)
                           }
                       }
        }
        
        
    }
