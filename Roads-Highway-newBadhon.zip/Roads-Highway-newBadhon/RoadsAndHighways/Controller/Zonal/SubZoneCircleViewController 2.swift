//
//  SubZoneCircleViewController.swift
//  RoadsAndHighways
//
//  Created by AL Mustakim on 12/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

class SubZoneCircleViewController: UIViewController {

    @IBOutlet weak var subZoneTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
        customNavigationBar()

        
    }
    


}
