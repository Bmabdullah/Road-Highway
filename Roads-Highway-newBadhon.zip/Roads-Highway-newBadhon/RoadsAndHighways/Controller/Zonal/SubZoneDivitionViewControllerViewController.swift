//
//  SubZoneDivitionViewControllerViewController.swift
//  RoadsAndHighways
//
//  Created by AL Mustakim on 12/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

class SubZoneDivitionViewControllerViewController: UIViewController {

    @IBOutlet weak var SubZoneDivitionTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        setupTableView()
        customNavigationBar()
    }
}
