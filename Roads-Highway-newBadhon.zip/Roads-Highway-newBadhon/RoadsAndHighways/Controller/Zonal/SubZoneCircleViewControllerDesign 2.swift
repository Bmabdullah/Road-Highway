//
//  SubZoneCircleViewControllerDesign.swift
//  RoadsAndHighways
//
//  Created by AL Mustakim on 12/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

extension SubZoneCircleViewController{
    func setupTableView(){
        subZoneTableView.delegate = self
        subZoneTableView.dataSource = self
        subZoneTableView.register(UINib(nibName: "SimpleTableViewCell", bundle: nil), forCellReuseIdentifier: "simpleCell")
    }
}

extension SubZoneCircleViewController : UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = subZoneTableView.dequeueReusableCell(withIdentifier: "simpleCell", for: indexPath)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        DispatchQueue.main.async {
                           
                           if let nav = self.navigationController{
                               Navigation.shared.nextViewControllerwithID(stroyBoardID: "Badhon",storyBoardName: "SubZoneDivitionViewControllerViewController", navigationController: nav)
                           }
                       }

    }
    
    
}
