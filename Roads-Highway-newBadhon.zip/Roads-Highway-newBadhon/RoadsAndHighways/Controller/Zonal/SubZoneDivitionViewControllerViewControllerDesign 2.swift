//
//  SubZoneDivitionViewControllerViewControllerDesign.swift
//  RoadsAndHighways
//
//  Created by AL Mustakim on 12/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

extension SubZoneDivitionViewControllerViewController{
    func setupTableView(){
        SubZoneDivitionTableView.delegate = self
        SubZoneDivitionTableView.dataSource = self
        SubZoneDivitionTableView.register(UINib(nibName: "SimpleTableViewCell", bundle: nil), forCellReuseIdentifier: "simpleCell")
    }
    
    
}
extension SubZoneDivitionViewControllerViewController:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = SubZoneDivitionTableView.dequeueReusableCell(withIdentifier: "simpleCell", for: indexPath)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
           DispatchQueue.main.async {
                              
                              if let nav = self.navigationController{
                                  Navigation.shared.nextViewControllerwithID(stroyBoardID: "Badhon",storyBoardName: "subdivisionviewcontroller", navigationController: nav)
                              }
                          }

       }

}
