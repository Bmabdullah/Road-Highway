//
//  PlaningViewControllerDesign.swift
//  RoadsAndHighways
//
//  Created by AL Mustakim on 10/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

extension PlaningViewController{
    
    func setupTableView() {
        
        planingTableView.delegate = self
                    planingTableView.dataSource = self
                   // let nib = UINib(nibName: "ItemTableViewCell", bundle: nil)
                    planingTableView.register(UINib(nibName: "ItemTableViewCell", bundle: nil), forCellReuseIdentifier: "tableCellIdentifier")
    }
    
}
extension PlaningViewController:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 6
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = planingTableView.dequeueReusableCell(withIdentifier: "tableCellIdentifier", for: indexPath) as! ItemTableViewCell
        
        cell.tableNibLabel.text = tabLeData?.data?[indexPath.row].name
        
        return cell
    }
}
