//
//  MechanicalServiceViewControllerDesign.swift
//  RoadsAndHighways
//
//  Created by AL Mustakim on 12/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

extension MechanicalServiceViewController{
    func setupTableView(){
        mechanicleTableView.delegate = self
        mechanicleTableView.dataSource = self
        mechanicleTableView.register(UINib(nibName: "ItemTableViewCell", bundle: nil), forCellReuseIdentifier: "tableCellIdentifier")
    }
    
    
}

extension MechanicalServiceViewController:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 6
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = mechanicleTableView.dequeueReusableCell(withIdentifier: "tableCellIdentifier", for: indexPath)
        
        return cell
    }
    
    
}

