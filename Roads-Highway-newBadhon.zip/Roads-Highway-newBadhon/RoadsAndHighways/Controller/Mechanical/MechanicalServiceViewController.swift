//
//  MechanicalServiceViewController.swift
//  RoadsAndHighways
//
//  Created by AL Mustakim on 9/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

class MechanicalServiceViewController: UIViewController {
    @IBOutlet weak var mechanicleTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupTableView()
        customNavigationBar()
    }
    
    
}
