//
//  SmsViewControllerDesign.swift
//  RoadsAndHighways
//
//  Created by AL Mustakim on 10/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

extension SmsViewController {

    func setupTableView(){
        smsTableView.delegate = self
         smsTableView.dataSource = self
        // let nib = UINib(nibName: "ItemTableViewCell", bundle: nil)
         smsTableView.register(UINib(nibName: "ItemTableViewCell", bundle: nil), forCellReuseIdentifier: "tableCellIdentifier")
    }
    
}


extension SmsViewController:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:ItemTableViewCell = smsTableView.dequeueReusableCell(withIdentifier: "tableCellIdentifier", for: indexPath) as! ItemTableViewCell
        cell.tableNibLabel.text = smsName[indexPath.row]
        cell.tableNibImageView.image = smsImage[indexPath.row]
        
        return cell
    }
    
    
}
