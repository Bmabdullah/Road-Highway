//
//  SmsViewController.swift
//  RoadsAndHighways
//
//  Created by AL Mustakim on 9/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

class SmsViewController: UIViewController {
    
    let smsName = ["Send All Department","Send Individual Depaartment"]
    let smsImage:[UIImage] = [UIImage(imageLiteralResourceName:"sendsms"), UIImage(imageLiteralResourceName: "sendsms")]
    
    @IBOutlet weak var smsTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
    }
    
    
    
    
}
