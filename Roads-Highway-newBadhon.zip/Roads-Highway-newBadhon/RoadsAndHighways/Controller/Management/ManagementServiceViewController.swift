//
//  ManagementServiceViewController.swift
//  RoadsAndHighways
//
//  Created by AL Mustakim on 9/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

protocol MyCollectionViewDelegate {
    
    func setupCollectionFlowLayout(_ collectionView:UICollectionView, collectionViewFlowLayout:UICollectionViewFlowLayout) -> Bool
}

struct ManageMentModel{
    let name:String?
    let image:UIImage?
    init(name:String?, image:UIImage?) {
        self.name  = name
        self.image = image
    }
}
let ob1 = ManageMentModel(name:"SMS", image: UIImage(named: "sms"))
let ob2 = ManageMentModel(name:"Email", image: UIImage(named: "email"))
let ob3 = ManageMentModel(name:"EmployeeList", image: UIImage(named: "employeelist"))


class ManagementServiceViewController: UIViewController, UICollectionViewDelegateFlowLayout{
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    var collectionViewFlowLayout: UICollectionViewFlowLayout!
    
    var listmanageMent = [ManageMentModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.barTintColor = UIColor.white
        self.navigationController?.navigationBar.tintColor = UIColor.black
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.black]
        
        collectionView.delegate = self
        collectionView.dataSource = self
        //register nib
        let nib = UINib(nibName: "ItemCollectionViewCell", bundle: nil)
        collectionView.register(nib, forCellWithReuseIdentifier: "cellIdentifier")
        
        
        listmanageMent.append(ob1)
        listmanageMent.append(ob2)
        listmanageMent.append(ob3)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    
    override func viewWillLayoutSubviews() {
        
        super.viewWillLayoutSubviews()
        setupCollectionFlowLayout()
    }
    
    
}

extension ManagementServiceViewController:UICollectionViewDelegate,UICollectionViewDataSource{
    
    
    private func setupCollectionFlowLayout() {
        let numberOfItemPerRow: CGFloat = 2
        
        let lineSpacing: CGFloat = 10
        let interItemSpacing: CGFloat = 10
        
        let width = (collectionView.frame.width - (numberOfItemPerRow - 1) * interItemSpacing) / numberOfItemPerRow
        
        collectionViewFlowLayout = UICollectionViewFlowLayout()
        
        collectionViewFlowLayout.itemSize = CGSize(width: width, height: width)
        collectionViewFlowLayout.sectionInset = UIEdgeInsets.zero
        collectionViewFlowLayout.scrollDirection = .vertical
        collectionViewFlowLayout.minimumLineSpacing = lineSpacing
        collectionViewFlowLayout.minimumInteritemSpacing = interItemSpacing
        collectionView.setCollectionViewLayout(collectionViewFlowLayout, animated: true)
        
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listmanageMent.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell:ItemCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellIdentifier", for: indexPath) as! ItemCollectionViewCell
        
        cell.nibLabel.text = listmanageMent[indexPath.row].name ?? ""
        cell.nibImageView.image = listmanageMent[indexPath.row].image
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
       
        
        switch (indexPath.row) {
        case 0:
            DispatchQueue.main.async {
                
                if let nav = self.navigationController{
                    Navigation.shared.nextViewControllerwithID(stroyBoardID: "Badhon",storyBoardName: "SmsViewController", navigationController: nav)
                }
            }
            
            break
        case 1:
            
            DispatchQueue.main.async {
                
                if let nav = self.navigationController{
                    Navigation.shared.nextViewControllerwithID(stroyBoardID: "Badhon",storyBoardName: "EmailViewController", navigationController: nav)
                }
            }

            break
        case 2:
            
            break
        default:
            break
        }
    }
}
