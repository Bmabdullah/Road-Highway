//
//  ManagementServicesWingViewController.swift
//  RoadsAndHighways
//
//  Created by Fahim Rahman on 12/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

class ManagementServicesWingViewController: UIViewController {

    @IBOutlet weak var managementServicesWingsTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = UIColor(hex: "#E5E5E5")
        self.managementServicesWingsTableView.backgroundColor = UIColor(hex: "#E5E5E5")
        
        managementServicesWingsTableView.delegate = self
        managementServicesWingsTableView.dataSource = self
        
        managementServicesWingsTableView.separatorStyle = .none
        managementServicesWingsTableView.showsVerticalScrollIndicator = false
        
        managementServicesWingsTableView.register(UINib(nibName: "ManagementServicesWingTableViewCell", bundle: nil), forCellReuseIdentifier: "mswCell")
    }
}



extension ManagementServicesWingViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "mswCell", for: indexPath)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 120
    }
    
    
}
