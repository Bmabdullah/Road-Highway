//
//  EmailViewController.swift
//  RoadsAndHighways
//
//  Created by AL Mustakim on 10/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

class EmailViewController: UIViewController {
    let emailName = ["Send All","Send Individual"]
    let emailImage:[UIImage] = [UIImage(imageLiteralResourceName:"mail"), UIImage(imageLiteralResourceName: "mail")]
    
    @IBOutlet weak var emailTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupTableView()
    }
    
}
