//
//  ManagementServicesWingTableViewCell.swift
//  RoadsAndHighways
//
//  Created by Fahim Rahman on 12/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

class ManagementServicesWingTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var profileImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.profileImageView.layer.cornerRadius = self.profileImageView.frame.height / 2
        
        contentView.layer.borderWidth = 5
        contentView.layer.borderColor = UIColor(hex: "#E5E5E5").cgColor
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }
    
}
