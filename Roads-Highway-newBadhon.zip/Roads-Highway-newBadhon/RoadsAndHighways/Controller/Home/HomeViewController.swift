//
//  HomeViewController.swift
//  RoadsAndHighways
//
//  Created by AL Mustakim on 8/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController, UICollectionViewDelegateFlowLayout, CAAnimationDelegate {
    @IBOutlet weak var homeCollectionView: UICollectionView!
    fileprivate var collectionViewFlowLayout: UICollectionViewFlowLayout!
    
    var mainCategory : CategoryBase?
    // var mainCategoryData : CategoryData?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "RHD APP"
        homeCollectionView.delegate = self
        homeCollectionView.dataSource = self
        homeCollectionView.showsVerticalScrollIndicator = false
        
        setNavigation()
        getHomeMenu(token: "\(defaults.string(forKey: "token")!)")
        
        if defaults.string(forKey: "token") != "" {

            loginRequest(mobileNumber: "01730782515")
            
            DispatchQueue.main.async {
                self.showSimpleHUD(hudView: self.view)
            }
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        customNavigationBar()
    }
}



extension HomeViewController : UICollectionViewDelegate,UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return mainCategory?.data?.count ?? 8
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = homeCollectionView.dequeueReusableCell(withReuseIdentifier: "HomeCollectionViewCell", for: indexPath) as! HomeCollectionViewCell
        
        cell.homeCollectionLabel.text = listhome.home?[indexPath.row].name ?? ""
        cell.homeCollectionLabel.font = UIFont(name: "Roboto", size: 19.0)
        cell.homeCollectionImageView.image = listhome.home?[indexPath.row].image
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let numberOfItemPerRow: CGFloat = 2
        
        let interItemSpacing: CGFloat = 10
        
        let width = (homeCollectionView.frame.width - (numberOfItemPerRow - 1) * interItemSpacing) / numberOfItemPerRow
        
        return CGSize(width: width, height: 180)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        //print(indexPath.row)
        
        if indexPath.row <= 5{
            
            if let vc = storyboard?.instantiateViewController(withIdentifier: "ChiefEngineersViewController") as? ChiefEngineersViewController {
                
                vc.id = mainCategory?.data?[indexPath.row].cOMPID ?? 9
                navigationController?.pushViewController(vc, animated: true)
            }
            
        }
        else if indexPath.row == 6{
            print("Zonal Operation")
            if let vc = storyboard?.instantiateViewController(withIdentifier: "ZonalOperationViewController") as? ZonalOperationViewController {
                
               // vc.id = mainCategory?.data?[indexPath.row].cOMPID ?? 9
                navigationController?.pushViewController(vc, animated: true)
            }
            
        }
            
        else if indexPath.row > 6 {
            
            print("project office")
            if let vc = storyboard?.instantiateViewController(withIdentifier: "PlaningViewController") as? PlaningViewController {
                
               // vc.id = mainCategory?.data?[indexPath.row].cOMPID ?? 9
                navigationController?.pushViewController(vc, animated: true)
            }
        }
        //                  DispatchQueue.main.async {
        //
        //
        //                      if let nav = self.navigationController{
        //                          Navigation.shared.nextViewControllerwithID(stroyBoardID: "Badhon",storyBoardName: "ChiefEngineersViewController", navigationController: nav)
        //                      }
        //                  }
        
        //        switch (indexPath.row) {
        //
        //        case CellClicked.chefEngineer.rawValue:
        //
        //            break
        //        case CellClicked.managementService.rawValue:
        //            DispatchQueue.main.async {
        //
        //                if let nav = self.navigationController{
        //                    Navigation.shared.nextViewControllerwithID(stroyBoardID: "Badhon",storyBoardName: "ManagementServiceViewController", navigationController: nav)
        //                }
        //            }
        //            break
        //        case CellClicked.planningMaintenance.rawValue:
        //            DispatchQueue.main.async {
        //
        //                if let nav = self.navigationController{
        //                    Navigation.shared.nextViewControllerwithID(stroyBoardID: "Badhon",storyBoardName: "PlaningViewController", navigationController: nav)
        //                }
        //            }
        //            break
        //        case CellClicked.technicalService.rawValue:
        //            DispatchQueue.main.async {
        //
        //                if let nav = self.navigationController{
        //                    Navigation.shared.nextViewControllerwithID(stroyBoardID: "Badhon",storyBoardName: "TechnicalViewController", navigationController: nav)
        //                }
        //            }
        //            break
        //        case CellClicked.bridgeManagemet.rawValue:
        //            DispatchQueue.main.async {
        //
        //                if let nav = self.navigationController{
        //                    Navigation.shared.nextViewControllerwithID(stroyBoardID: "Badhon",storyBoardName: "BridgeViewController", navigationController: nav)
        //                }
        //            }
        //            break
        //        case CellClicked.mechanicalService.rawValue:
        //            DispatchQueue.main.async {
        //
        //                if let nav = self.navigationController{
        //                    Navigation.shared.nextViewControllerwithID(stroyBoardID: "Badhon",storyBoardName: "MechanicalServiceViewController", navigationController: nav)
        //                }
        //            }
        //            break
        //        case CellClicked.zonalOperation.rawValue:
        //            DispatchQueue.main.async {
        //
        //                if let nav = self.navigationController{
        //                    Navigation.shared.nextViewControllerwithID(stroyBoardID: "Badhon",storyBoardName: "ZonalOperationViewController", navigationController: nav)
        //                }
        //            }
        //            break
        //        case CellClicked.projectOffice.rawValue:
        //            //            DispatchQueue.main.async {
        //            //
        //            //                if let nav = self.navigationController{
        //            //                    Navigation.shared.nextViewControllerwithID(stroyBoardID: "Badhon",storyBoardName: "ManagementServiceViewController", navigationController: nav)
        //            //                }
        //            //            }
        //            print("NO Design Found")
        //            break
        //
        //        default:
        //            break
        //        }
    }
    
}

extension HomeViewController{
    
    func setNavigation() {
        
        navigationController?.setNavigationBarHidden(false, animated: false)
        
        let leftItem = UIBarButtonItem(image: UIImage(named: "menuicon"), style: .plain, target: self,action: #selector(leftNavigationItemClicked))
        
        self.navigationItem.leftBarButtonItem  = leftItem
        self.navigationItem.leftBarButtonItem?.tintColor = UIColor.white
        
        navigationController?.navigationBar.barTintColor = UIColor(hex: "363A44")
        navigationController?.navigationBar.tintColor = UIColor.white
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        
    }
    
    @objc func leftNavigationItemClicked() {
        
        DispatchQueue.main.async {
            
            let storyBoard : UIStoryboard = UIStoryboard(name: "Fahim", bundle:nil)
            if let vc = storyBoard.instantiateViewController(withIdentifier: "MenuViewController") as? MenuViewController {
                
                let transition = CATransition()
                transition.duration = 0.32
                
                transition.type = CATransitionType.push
                transition.subtype = CATransitionSubtype.fromLeft
                
                self.navigationController?.view.layer.add(transition, forKey: kCATransition)
                
                self.navigationController?.pushViewController(vc, animated: false)
            }
        }
    }
}



extension HomeViewController {
    
    func getHomeMenu(token: String) {
        
        guard let loginUrl = URL(string: UrlManager.baseURL() + "rhd/GetMainCategory") else { return }
        
        var request = URLRequest(url: loginUrl)
        request.setValue("Bearer \(String(describing: token))", forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "GET"
        // request.httpBody = postData
        request.timeoutInterval = .infinity
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            
            DispatchQueue.main.async {
                
                if let response = response as? HTTPURLResponse, response.isResponseOK() {
                    // print(response)
                    
                    guard let data = data else {
                        print(String(describing: error))
                        return
                    }
                    
                    if let jsonResponse = try? JSONDecoder().decode(CategoryBase.self, from: data) {
                        
                        //make a json type variable ande store response here
                        
                        self.mainCategory = jsonResponse
                        
                    }
                    
                    hud.dismiss(animated: true)
                }
            }
        }.resume()
    }
}




// api request

extension HomeViewController {
    
    func loginRequest(mobileNumber: String) {
        print("aaa")
        guard let loginUrl = URL(string: UrlManager.baseURL() + "login/UserLogin") else { return }
        
        let parameters = "{\r\n    \"Mobile\":\"\(mobileNumber)\"\r\n}"
        let postData = parameters.data(using: .utf8)
        
        var request = URLRequest(url: loginUrl)
        
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "POST"
        request.httpBody = postData
        request.timeoutInterval = .infinity
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            
            DispatchQueue.main.async {
                
                if let response = response as? HTTPURLResponse, response.isResponseOK() {
                    
                    guard let data = data else {
                        print(String(describing: error))
                        return
                    }
                    
                    if let jsonResponse = try? JSONDecoder().decode(Login.self, from: data) {
                        
                        defaults.set(jsonResponse.data?.token, forKey: "token")
                        
                        print(defaults.string(forKey: "token")!) //SAVED TOKEN
                        
                        loginData = jsonResponse
                    }
                    
//                    let storyboard = UIStoryboard(name: "Badhon", bundle: nil)
                    
//                    if let vc = storyboard.instantiateViewController(withIdentifier: "homeVC") as? HomeViewController {
//
//                        self.navigationController?.pushViewController(vc, animated: true)
//                    }
                    
                    hud.dismiss(animated: true)
                }
            }
        }.resume()
    }
}
