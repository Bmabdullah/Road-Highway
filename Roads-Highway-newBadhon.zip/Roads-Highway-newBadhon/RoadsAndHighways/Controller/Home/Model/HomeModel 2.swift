//
//  HomeModel.swift
//  RoadsAndHighways
//
//  Created by Muhammad Abdullah Al Mamun on 11/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import Foundation
import UIKit


struct Home{
    let name:String?
    let image:UIImage?
    
    init(name:String?, image:UIImage?){
        self.name = name
        self.image = image
    }
 
}

struct HomeList{
    
    var home : [Home]?
    
    init(home: [Home]) {
        self.home = home
    }
}

let listhome:HomeList = HomeList(home: [Home(name: "Chief Engineers Office", image: UIImage(named: "chefengineer")),
                               Home(name: "Management Services", image: UIImage(named: "management")),
                               Home(name: "Planning and Maintenance", image: UIImage(named: "planning")),
                               Home(name: "Technical Service", image: UIImage(named: "technical")),
                               Home(name: "Bridge Management", image: UIImage(named: "bridge")),
                               Home(name: "Mechanical Services", image: UIImage(named: "mecanical")),
                               Home(name: "Zonal Operation", image: UIImage(named: "zonaloperation")),
                               Home(name: "Project Office", image: UIImage(named: "projectoffice")),
                               ])




