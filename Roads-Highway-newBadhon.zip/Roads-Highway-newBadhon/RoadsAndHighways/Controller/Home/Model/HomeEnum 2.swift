//
//  HomeEnum.swift
//  RoadsAndHighways
//
//  Created by Muhammad Abdullah Al Mamun on 11/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import Foundation

enum CellClicked: Int {
    
    case chefEngineer         
    case managementService
    case planningMaintenance
    case technicalService
    case bridgeManagemet
    case mechanicalService
    case zonalOperation
    case projectOffice
}
