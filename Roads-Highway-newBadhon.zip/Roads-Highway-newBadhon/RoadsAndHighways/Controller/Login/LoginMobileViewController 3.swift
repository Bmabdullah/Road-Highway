//
//  LoginMobileViewController.swift
//  RoadsAndHighways
//
//  Created by Muhammad Abdullah Al Mamun on 11/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

enum Rounder {
    
    static func roundView(getter:UIView){
        getter.layer.cornerRadius = 15.0
    }
    
    static func roundButton(getter:UIButton){
        getter.layer.cornerRadius = 10.0
    }
    
    static func placingTextField(loginTextField:UITextField, color:UIColor){
        loginTextField.attributedPlaceholder = NSAttributedString(string: " +88 Enter Mobile Number",
                                                                  attributes: [NSAttributedString.Key.foregroundColor: color])
    }
}


class LoginMobileViewController: UIViewController {
    
    
    @IBOutlet weak var logoImage: UIImageView!

    
    @IBOutlet weak var LoginView: UIView!
    
    @IBOutlet weak var loginTextField: UITextField!
    
    @IBOutlet weak var nextButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        settingUI()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    
    @IBAction func nextButtonAction(_ sender: UIButton) {
        
        DispatchQueue.main.async {
            
            if let nav = self.navigationController{
                Navigation.shared.nextViewControllerwithID(stroyBoardID: "Fahim",storyBoardName: "otpVC", navigationController: nav)
            }
        }
    }
}



extension LoginMobileViewController{
    
    func  settingUI(){
        Rounder.roundView(getter: LoginView)
        Rounder.roundButton(getter: nextButton)
        Rounder.placingTextField(loginTextField: loginTextField, color: UIColor.lightText)
        
    }
}
