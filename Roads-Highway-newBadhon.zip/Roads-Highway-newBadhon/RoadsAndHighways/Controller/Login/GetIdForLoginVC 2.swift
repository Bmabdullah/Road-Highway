//
//  ViewController.swift
//  RoadsAndHighways
//
//  Created by Fahim Rahman on 7/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

class GetIdForLoginViewController: UIViewController {

    @IBOutlet weak var middleView: UIView!
    
    @IBOutlet weak var otpConfirmButton: UIButton!
    
    @IBOutlet weak var otp1TextField: SDCTextField!
    @IBOutlet weak var otp2TextField: SDCTextField!
    @IBOutlet weak var otp3TextField: SDCTextField!
    @IBOutlet weak var otp4TextField: SDCTextField!
    @IBOutlet weak var otp5TextField: SDCTextField!
    @IBOutlet weak var otp6TextField: SDCTextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        designGetIdForLogin()
        touchToDismissKeyboard()
    }
    
    @IBAction func otpConfirmButtonAction(_ sender: UIButton) {
        
        DispatchQueue.main.async {
            
            if let nav = self.navigationController{
                Navigation.shared.nextViewControllerwithID(stroyBoardID: "Badhon",storyBoardName: "homeVC", navigationController: nav)
            }
        }
    }
}


extension GetIdForLoginViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {

        // Verify all the conditions
        if let sdcTextField = textField as? SDCTextField {
            return sdcTextField.verifyFields(shouldChangeCharactersIn: range, replacementString: string)
        }

        return false
    }
}
