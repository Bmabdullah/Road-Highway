//
//  EditProfileViewController.swift
//  RoadsAndHighways
//
//  Created by Fahim Rahman on 9/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

class EditProfileViewController: UIViewController {

    @IBOutlet weak var backView: UIView!
    
    @IBOutlet weak var saveAndUpdateButton: UIButton!
    
    @IBOutlet weak var profileImageView: UIView!
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var idTextField: UITextField!
    @IBOutlet weak var designationTextField: UITextField!
    @IBOutlet weak var officeNameTextField: UITextField!
    @IBOutlet weak var circleOfficeTextField: UITextField!
    @IBOutlet weak var officialContactTextField: UITextField!
    @IBOutlet weak var personalContactTextField: UITextField!
    @IBOutlet weak var officialEmailTextField: UITextField!
    @IBOutlet weak var personalEmailTextField: UITextField!
    @IBOutlet weak var tinNumberTextField: UITextField!
    @IBOutlet weak var passportTextField: UITextField!
    @IBOutlet weak var drivingLicenceTextField: UITextField!
    @IBOutlet weak var maritalStatusTextField: UITextField!
    @IBOutlet weak var addressTextField: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        designEditProfileVC()
    }
}
