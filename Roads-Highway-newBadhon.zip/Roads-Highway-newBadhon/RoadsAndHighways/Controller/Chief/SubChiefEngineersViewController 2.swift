//
//  SubChiefEngineersViewController.swift
//  RoadsAndHighways
//
//  Created by AL Mustakim on 12/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

class SubChiefEngineersViewController: UIViewController {

    @IBOutlet weak var subChifEngineersTableView: UITableView!
    
    var id : Int = 0
    var tabLeData : CategoryBase?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupTableview()
        customNavigationBar()
        navigationHomeButton()
        
        DispatchQueue.main.async {
            
            self.showSimpleHUD(hudView: self.view)
        }
        gettableData(token: "\(defaults.string(forKey: "token")!)")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        customNavigationBar()
    }


}
extension SubChiefEngineersViewController {
    
    func gettableData(token: String) {
        
        guard let loginUrl = URL(string: UrlManager.baseURL() + "rhd/GetNextCategoryByParent?parent=\(id)") else { return }
        
        var request = URLRequest(url: loginUrl)
        request.setValue("Bearer \(String(describing: token))", forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "GET"
        // request.httpBody = postData
        request.timeoutInterval = .infinity
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            
            DispatchQueue.main.async {
                
                if let response = response as? HTTPURLResponse, response.isResponseOK() {
                    print(response)
                    
                    guard let data = data else {
                        print(String(describing: error))
                        return
                    }
                    
                    if let jsonResponse = try? JSONDecoder().decode(CategoryBase.self, from: data) {
                        
                        
                        self.tabLeData = jsonResponse
                        
                    }
                    self.subChifEngineersTableView.reloadData()
                    
                    hud.dismiss(animated: true)
                }
            }
        }.resume()
    }
}

