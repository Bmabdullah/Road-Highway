//
//  SubChiefEngineersViewControllerDesign.swift
//  RoadsAndHighways
//
//  Created by AL Mustakim on 12/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

extension SubChiefEngineersViewController{
    
    func setupTableview(){
            subChifEngineersTableView.delegate = self
            subChifEngineersTableView.dataSource = self
            subChifEngineersTableView.register(UINib(nibName: "SimpleTableViewCell", bundle: nil), forCellReuseIdentifier: "simpleCell")
        }
    }

    extension SubChiefEngineersViewController:UITableViewDataSource,UITableViewDelegate{
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return tabLeData?.data?.count ?? 6
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = subChifEngineersTableView.dequeueReusableCell(withIdentifier: "simpleCell", for: indexPath) as! SimpleTableViewCell
            cell.simpleCellLabel.text = tabLeData?.data?[indexPath.row].name
            return cell
        }
        
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let vc = storyboard?.instantiateViewController(withIdentifier: "TechnicalViewController") as! TechnicalViewController
            vc.id = tabLeData?.data?[indexPath.row].cOMPID ?? 9
            navigationController?.pushViewController(vc, animated: true)
        }
        
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 120
            
        }

    }
