//
//  ChiefEngineersViewControllerDesign.swift
//  RoadsAndHighways
//
//  Created by AL Mustakim on 11/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import UIKit

extension ChiefEngineersViewController{
    func setupTableView(){
        chiefTableView.delegate = self
        chiefTableView.dataSource = self
        chiefTableView.showsVerticalScrollIndicator = false
    }
    
}

extension ChiefEngineersViewController: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tabLeData?.data?.count ?? 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = chiefTableView.dequeueReusableCell(withIdentifier: "ChiefEngineerscell", for: indexPath) as! ChiefEngineersTableViewCell
        cell.chefTableCellLabel.text = tabLeData?.data?[indexPath.row].name
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 100
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       
        let vc = storyboard?.instantiateViewController(withIdentifier: "SubChiefEngineersViewController") as! SubChiefEngineersViewController
        vc.id = tabLeData?.data?[indexPath.row].cOMPID ?? 9
        navigationController?.pushViewController(vc, animated: true)
    }
    
    
}
