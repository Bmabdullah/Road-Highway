//
//  Defaults.swift
//  RoadsAndHighways
//
//  Created by Muhammad Abdullah Al Mamun on 15/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import Foundation

class Defaults {
    
    class var username: String? {
        get {
            // #function means the function name, or in this case, the variable name,
            // which is "mobileNumber"
           return UserDefaults.standard.string(forKey: #function)
        }
        set {
           UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
}
