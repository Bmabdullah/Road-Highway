//
//  HomeEnum.swift
//  RoadsAndHighways
//
//  Created by Muhammad Abdullah Al Mamun on 11/7/20.
//  Copyright © 2020 Fahim Rahman. All rights reserved.
//

import Foundation

enum CellClicked: Int {
    
    case planningMaintenance
    case technicalService
    case mechanicalService
    case bridgeManagemet
    case managementService
    case chefEngineer
    case zonalOperation
    case projectOffice
}
